import { Button } from '@/components/ui/button'
import Link from 'next/link'

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">About Middle Man</h1>
      <div className="space-y-6">
        <p>
          At Middle Man, we specialize in simplifying and streamlining the B2B cold email process. Our mission is to help businesses connect with their ideal clients by managing every aspect of cold email outreach, from initial setup to scheduled meetings.
        </p>
        <p>
          We pride ourselves on delivering a comprehensive, results-driven service designed to maximize efficiency and ensure your outreach campaigns succeed.
        </p>
        <h2 className="text-2xl font-semibold mt-8 mb-4">What We Offer</h2>
        <ul className="list-disc pl-6 space-y-2">
          <li><strong>Infrastructure Setup:</strong> We build a solid foundation for your campaigns, ensuring they are optimized for long-term success.</li>
          <li><strong>Automated Campaigns:</strong> Our advanced systems automate email outreach, providing consistency and saving you valuable time.</li>
          <li><strong>Reply Management:</strong> Every response is carefully monitored and managed, so you never miss an opportunity.</li>
          <li><strong>Meeting Booking:</strong> Positive replies are seamlessly converted into scheduled meetings with qualified leads.</li>
          <li><strong>Deliverability Optimization:</strong> We implement best practices to ensure your emails reach the right inboxes.</li>
        </ul>
        <h2 className="text-2xl font-semibold mt-8 mb-4">Why Choose Us?</h2>
        <p>Our end-to-end approach ensures a hassle-free experience for your business:</p>
        <ul className="list-disc pl-6 space-y-2">
          <li><strong>Customized Setup & Strategy:</strong> Tailored solutions to fit your goals and audience.</li>
          <li><strong>Email Deliverability:</strong> Strategies that maximize the success of your outreach.</li>
          <li><strong>Automated Outreach:</strong> Personalized campaigns with AI-driven precision.</li>
          <li><strong>Reply & Lead Management:</strong> Effective handling of responses to secure every lead.</li>
          <li><strong>Meeting Coordination:</strong> We take care of scheduling, so you focus on closing deals.</li>
          <li><strong>Ongoing Optimization:</strong> Continuous improvements to deliver even better results.</li>
        </ul>
        <div className="mt-8">
          <Link href="/contact">
            <Button>Contact Us</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

