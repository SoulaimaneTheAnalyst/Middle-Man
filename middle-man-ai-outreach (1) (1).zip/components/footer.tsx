import { ArrowRightLeft } from "lucide-react"

export default function Footer() {
  return (
    <footer className="py-8 px-4 md:px-6 lg:px-8 bg-gray-100 text-center">
      <div className="max-w-5xl mx-auto">
        <div className="flex justify-center items-center mb-4">
          <ArrowRightLeft className="h-6 w-6 mr-2 text-primary" />
          <span className="text-xl font-bold text-primary">Middle Man</span>
        </div>
        <p className="text-gray-600">© {new Date().getFullYear()} Middle Man. All rights reserved.</p>
      </div>
    </footer>
  )
}

