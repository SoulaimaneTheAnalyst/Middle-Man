import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Settings, Send, MessageSquare, Calendar, Shield } from 'lucide-react'

const features = [
  {
    icon: <Settings className="h-8 w-8 mb-4 text-primary" />,
    title: 'Full Infrastructure Setup',
    description: 'We handle the entire cold email setup process, ensuring your campaigns are built on a solid foundation.'
  },
  {
    icon: <Send className="h-8 w-8 mb-4 text-primary" />,
    title: 'Automated Campaigns',
    description: 'Our system automates your email campaigns, saving you time and ensuring consistent outreach.'
  },
  {
    icon: <MessageSquare className="h-8 w-8 mb-4 text-primary" />,
    title: 'Reply Management',
    description: 'We monitor and manage replies, ensuring no potential lead slips through the cracks.'
  },
  {
    icon: <Calendar className="h-8 w-8 mb-4 text-primary" />,
    title: 'Meeting Booking',
    description: 'From replies to scheduled meetings, we handle the entire process to fill your calendar with potential clients.'
  },
  {
    icon: <Shield className="h-8 w-8 mb-4 text-primary" />,
    title: 'Maximized Deliverability',
    description: 'We implement best practices and constantly monitor to ensure your emails reach their intended recipients.'
  }
]

export default function Features() {
  return (
    <section id="features" className="py-20 px-4 md:px-6 lg:px-8 bg-gray-50">
      <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Comprehensive B2B Email Outreach</h2>
      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {features.map((feature, index) => (
          <Card key={index} className="text-center">
            <CardHeader>
              <div className="flex justify-center">{feature.icon}</div>
              <CardTitle>{feature.title}</CardTitle>
              <CardDescription>{feature.description}</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </div>
    </section>
  )
}

