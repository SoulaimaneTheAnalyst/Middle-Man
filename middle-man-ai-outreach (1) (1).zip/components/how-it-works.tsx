import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Settings, Send, MessageSquare, Calendar, Shield, BarChart } from 'lucide-react'

const steps = [
  {
    icon: <Settings className="h-8 w-8 mb-4 text-primary" />,
    title: '1. Setup & Strategy',
    description: 'We set up your entire cold email infrastructure and develop a tailored outreach strategy.'
  },
  {
    icon: <Shield className="h-8 w-8 mb-4 text-primary" />,
    title: '2. Deliverability Optimization',
    description: 'We implement best practices to maximize your email deliverability rates.'
  },
  {
    icon: <Send className="h-8 w-8 mb-4 text-primary" />,
    title: '3. Automated Outreach',
    description: 'Our AI system sends personalized, automated email campaigns to your target audience.'
  },
  {
    icon: <MessageSquare className="h-8 w-8 mb-4 text-primary" />,
    title: '4. Reply Management',
    description: 'We monitor and manage all replies, ensuring timely and appropriate responses.'
  },
  {
    icon: <Calendar className="h-8 w-8 mb-4 text-primary" />,
    title: '5. Meeting Scheduling',
    description: 'For positive responses, we handle the process of scheduling meetings with potential clients.'
  },
  {
    icon: <BarChart className="h-8 w-8 mb-4 text-primary" />,
    title: '6. Continuous Optimization',
    description: 'We analyze campaign performance and continuously refine our approach for better results.'
  }
]

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 px-4 md:px-6 lg:px-8 bg-white">
      <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Our End-to-End Process</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {steps.map((step, index) => (
          <Card key={index} className="text-center">
            <CardHeader>
              <div className="flex justify-center">{step.icon}</div>
              <CardTitle>{step.title}</CardTitle>
              <CardDescription>{step.description}</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </div>
    </section>
  )
}

