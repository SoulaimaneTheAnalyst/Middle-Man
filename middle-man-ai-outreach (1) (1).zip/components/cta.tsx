import { ArrowRight } from 'lucide-react'
import { GetStartedForm } from './get-started-form'

export default function CTA() {
  return (
    <section id="contact" className="py-20 px-4 md:px-6 lg:px-8 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-center">
      <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your B2B Outreach?</h2>
      <p className="text-xl mb-8 max-w-2xl mx-auto">
        Let Middle Man handle your entire cold email process. From setup to booked meetings, we've got you covered. Start filling your calendar with qualified B2B leads today.
      </p>
      <GetStartedForm />
    </section>
  )
}

