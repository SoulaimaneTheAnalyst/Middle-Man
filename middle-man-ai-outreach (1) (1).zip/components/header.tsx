import Link from "next/link"
import { ArrowRightLeft } from "lucide-react"

export default function Header() {
  return (
    <header className="py-4 px-4 md:px-6 lg:px-8 flex items-center justify-between bg-white shadow-sm">
      <Link href="/" className="text-2xl font-bold text-blue-600 flex items-center">
        <ArrowRightLeft className="mr-2 h-6 w-6" />
        Middle Man
      </Link>
    </header>
  )
}

