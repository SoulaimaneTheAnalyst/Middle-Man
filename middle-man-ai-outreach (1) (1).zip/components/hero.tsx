import { ArrowRightLeft, Mail, Calendar } from 'lucide-react'
import { GetStartedForm } from './get-started-form'

export default function Hero() {
  return (
    <section className="py-20 px-4 md:px-6 lg:px-8 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-center">
      <div className="flex justify-center items-center mb-6 space-x-4">
        <Mail className="h-16 w-16" />
        <ArrowRightLeft className="h-12 w-12" />
        <Calendar className="h-16 w-16" />
      </div>
      <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
        Middle Man: Your all-in-one solution for B2B cold email campaigns. From setup to booked meetings.
      </h1>
      <GetStartedForm />
    </section>
  )
}

